pi = "oggy"
print(pi)
from math import pi
print(pi)
